package org.example.service;

public interface ManagerService {
    void createAdminIfNotExists();
}
