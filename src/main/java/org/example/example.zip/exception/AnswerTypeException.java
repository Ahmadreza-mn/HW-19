package org.example.exception;

public class AnswerTypeException extends RuntimeException{
    public AnswerTypeException(String message) {
        super(message);
    }
}