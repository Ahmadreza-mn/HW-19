package org.example.exception;

public class ScoreOfAnswerException extends RuntimeException {
    public ScoreOfAnswerException(String message) {
        super(message);
    }
}