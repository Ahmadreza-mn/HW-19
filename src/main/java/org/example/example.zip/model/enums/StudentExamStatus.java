package org.example.model.enums;

public enum StudentExamStatus {
    IN_PROGRESS , COMPLETED
}
