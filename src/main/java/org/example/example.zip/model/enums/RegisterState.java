package org.example.model.enums;

public enum RegisterState {
    WAITING,CONFIRM
}

