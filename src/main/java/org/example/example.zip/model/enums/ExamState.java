package org.example.model.enums;

public enum ExamState {
    NOT_STARTED, STARTED, FINISHED
}

