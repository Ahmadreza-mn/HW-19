package org.example.repository;

import org.example.model.Master;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class MasterRepository {
    private final SessionFactory sessionFactory;

    public MasterRepository(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void save(Master master) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.persist(master);
            tx.commit();
        }
    }

    public Master findById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Master.class, id);
        }
    }

    public void delete(Master master) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.remove(master);
            tx.commit();
        }
    }

    public void update(Master master) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.merge(master);
            tx.commit();
        }
    }
}