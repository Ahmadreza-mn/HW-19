package org.example.repository;

import org.example.model.Exam;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class ExamRepository {
    private final SessionFactory sessionFactory;

    public ExamRepository(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void save(Exam exam) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.persist(exam);
            tx.commit();
        }
    }

    public Exam findById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Exam.class, id);
        }
    }

    public void delete(Exam exam) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.remove(exam);
            tx.commit();
        }
    }

    public void update(Exam exam) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.merge(exam);
            tx.commit();
        }
    }
}
