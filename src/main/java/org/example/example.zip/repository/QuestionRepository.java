package org.example.repository;

import org.example.model.Question;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class QuestionRepository {
    private final SessionFactory sessionFactory;

    public QuestionRepository(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void save(Question question) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.persist(question);
            tx.commit();
        }
    }

    public Question findById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Question.class, id);
        }
    }

    public void delete(Question question) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.remove(question);
            tx.commit();
        }
    }

    public void update(Question question) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.merge(question);
            tx.commit();
        }
    }
}
