package org.example.repository;

import org.example.model.Answer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class AnswerRepository {
    private final SessionFactory sessionFactory;

    public AnswerRepository(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void save(Answer answer) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.persist(answer);
            tx.commit();
        }
    }

    public Answer findById(Long id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Answer.class, id);
        }
    }

    public void delete(Answer answer) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.remove(answer);
            tx.commit();
        }
    }

    public void update(Answer answer) {
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.merge(answer);
            tx.commit();
        }
    }
}